import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('view-count')

def lambda_handler(event, context):
    # Increment the views attribute by 1 using an atomic counter
    response = table.update_item(
        Key={'id': 0},
        UpdateExpression='SET #v = #v + :val',  # Use ExpressionAttributeNames for the attribute name
        ExpressionAttributeNames={'#v': 'views'},  # Specify an alternate name ('#v') for 'views'
        ExpressionAttributeValues={':val': 1},
        ReturnValues='UPDATED_NEW'
    )
    
    # Get the updated views count from the response
    views = response['Attributes']['views']
    
    return {
        "statusCode":200,
        "body":views
    }